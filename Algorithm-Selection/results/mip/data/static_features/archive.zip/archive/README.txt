Here are data directories produced by models that did not show the best results. 

Legend:
	a - Results of Alex's prediction models.
	b - Results of Bart's prediction models.

a_nonscaled - Data used for training was not scaled.
a_scaled_type1 - Data used for training was scaled ... EXPLAIN HOW 
a_scaled_type3 - Data used fot training was scaled ... EXPLAIN HOW

b_all_features - All classifiers trained on full set of features.
b_pca_71_features - All classifiers trained on 71 PCA features.
b_pca_features - All classifiers trained just on PCA features.
b_reduced_features - Classifiers trained on reduced set of features ... EXPLAIN HOW IS THE SET PRODUCED.
